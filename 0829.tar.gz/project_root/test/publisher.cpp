/**
 * @file publisher.cpp  
 * @brief 简化的FastDDS发布者 - 模拟车端发送消息
 */

#include "fastdds_publisher.hpp"
#include <iostream>
#include <memory>
#include <thread>
#include <chrono>
#include <signal.h>
#include <atomic>
#include <fstream>
#include <filesystem>
#include <iomanip>
#include <sstream>

std::unique_ptr<FastDDSPublisher> g_publisher = nullptr;
std::atomic<bool> g_running{true};

/**
 * @brief 按topic分类的日志记录器  
 */
class TopicLogger {
private:
    std::string session_dir_;
    std::map<std::string, std::ofstream> topic_files_;
    
public:
    TopicLogger() {
        // 创建session日志目录
        auto now = std::chrono::system_clock::now();
        auto time_t = std::chrono::system_clock::to_time_t(now);
        
        std::ostringstream oss;
        oss << std::put_time(std::localtime(&time_t), "%Y%m%d_%H%M%S");
        session_dir_ = "logs/fastdds/pub/" + oss.str();
        
        std::filesystem::create_directories(session_dir_);
        std::cout << "日志目录: " << session_dir_ << std::endl;
    }
    
    ~TopicLogger() {
        for (auto& pair : topic_files_) {
            if (pair.second.is_open()) {
                pair.second.close();
            }
        }
    }
    
    void log(const std::string& topic_path, const std::string& message) {
        // 确保topic日志文件存在
        if (topic_files_.find(topic_path) == topic_files_.end()) {
            std::string log_file_path = session_dir_ + "/" + topic_path + ".log";
            
            // 创建子目录
            std::filesystem::path log_path(log_file_path);
            std::filesystem::create_directories(log_path.parent_path());
            
            topic_files_[topic_path].open(log_file_path);
        }
        
        auto& log_file = topic_files_[topic_path];
        if (!log_file.is_open()) return;
        
        auto now = std::chrono::system_clock::now();
        auto time_t = std::chrono::system_clock::to_time_t(now);
        auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
            now.time_since_epoch()) % 1000;
        
        log_file << "[" << std::put_time(std::localtime(&time_t), "%Y-%m-%d %H:%M:%S")
                 << "." << std::setfill('0') << std::setw(3) << ms.count()
                 << "] " << message << std::endl;
        log_file.flush();
    }
    
    std::string get_topic_path(const std::string& topic_name) {
        if (topic_name == "handshake_request") {
            return "handshake/request";
        } else if (topic_name == "handshake_response") {
            return "handshake/response";
        } else if (topic_name == "vehicle_status") {
            return "vehicle/vehicle_status";
        } else if (topic_name == "remote_control") {
            return "vehicle/control_cmd";
        } else if (topic_name == "drive_state") {
            return "vehicle/drive_state";
        } else if (topic_name == "fault_report") {
            return "vehicle/fault_report";
        }
        return "unknown/" + topic_name;
    }
};

TopicLogger g_logger;

void signal_handler(int signal) {
    std::cout << "\n收到停止信号，退出程序..." << std::endl;
    g_running = false;
}

/**
 * @brief 发送测试消息
 */
void send_test_messages() {
    static int count = 0;
    count++;
    
    std::cout << "\n=== 发送第 " << count << " 轮测试消息（5个IDL） ===" << std::endl;
    
    // 1. 发送握手请求
    uint64_t timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    if (g_publisher->publishHandshakeRequest("/handshake/request", 1, 0, 1, timestamp)) {
        std::string msg = "HandshakeRequest发送成功: noa_active=1, override_status=0, override_ready=1, timestamp=" + std::to_string(timestamp);
        std::cout << "✓ " << msg << std::endl;
        g_logger.log(g_logger.get_topic_path("handshake_request"), msg);
    }
    
    // 2. 发送握手响应  
    if (g_publisher->publishHandshakeResponse("/handshake/response", 1, 1, true, timestamp)) {
        std::string msg = "HandshakeResponse发送成功: noa_active=1, override_response=1, control_source=true, timestamp=" + std::to_string(timestamp);
        std::cout << "✓ " << msg << std::endl;
        g_logger.log(g_logger.get_topic_path("handshake_response"), msg);
    }
    
    // 3. 发送车辆状态 (使用完整字段版本)
    uint32_t vehicle_id = 12345 + count;
    float speed = 60.0f + (count % 10);
    float altitude = 50.0f + count;
    float heading = 45.0f + (count % 360);
    float gear_position = 3.0f;
    int power_mode = 2; // ON状态
    float yawrate = 2.5f + (count % 5) * 0.5f;
    float acceleration = 1.2f + (count % 3) * 0.3f;
    float steering_angle = -15.0f + (count % 30);
    float wheel_angle = -12.0f + (count % 24);
    long ebrake_status = (count % 10 == 0) ? 1 : 0; // 每10轮激活一次手刹
    long indicator_left = (count % 6 == 0) ? 1 : 0;
    long indicator_right = (count % 6 == 1) ? 1 : 0;
    
    if (g_publisher->publishVehicleStatusFull("/vehicle/vehicle_status", 
            vehicle_id, 2, 116.397f, 39.916f, altitude, speed, 
            yawrate, gear_position, acceleration, heading, 
            steering_angle, wheel_angle, ebrake_status, 
            indicator_left, indicator_right, timestamp, power_mode)) {
        std::string msg = "VehicleStatus发送成功: vehicle_id=" + std::to_string(vehicle_id) + 
                         ", speed=" + std::to_string(speed) + ", control_mode=2" +
                         ", position=(116.397,39.916), altitude=" + std::to_string(altitude) + 
                         ", heading=" + std::to_string(heading) + ", yawrate=" + std::to_string(yawrate) +
                         ", gear=" + std::to_string(gear_position) + ", accel=" + std::to_string(acceleration) +
                         ", steering=" + std::to_string(steering_angle) + ", wheel=" + std::to_string(wheel_angle) +
                         ", ebrake=" + std::to_string(ebrake_status) + 
                         ", indicators=(L:" + std::to_string(indicator_left) + ",R:" + std::to_string(indicator_right) + ")" +
                         ", power_mode=" + std::to_string(power_mode) + ", timestamp=" + std::to_string(timestamp);
        std::cout << "✓ " << msg << std::endl;
        g_logger.log(g_logger.get_topic_path("vehicle_status"), msg);
    }
    
    // 4. 发送控制命令
    float steering = -10.0f + (count % 20);
    float accel = 0.5f + (count % 5) * 0.2f;
    bool cmd_indicator_left = (count % 4 == 0);
    bool cmd_indicator_right = (count % 4 == 1);
    int32_t gear_pos = 3;
    int32_t ebrake = 0;
    if (g_publisher->publishRemoteControl("/vehicle/control_cmd", 
            true, steering, true, accel,
            cmd_indicator_left, cmd_indicator_left, cmd_indicator_right, cmd_indicator_right,
            true, gear_pos, true, ebrake, timestamp)) {
        std::string msg = "ControlCmd发送成功: steering_enable=true, steering=" + std::to_string(steering) +
                         ", accel_enable=true, accel=" + std::to_string(accel) +
                         ", indicators=(L:" + std::to_string(cmd_indicator_left) + ",R:" + std::to_string(cmd_indicator_right) + ")" +
                         ", gear=" + std::to_string(gear_pos) + ", ebrake=" + std::to_string(ebrake) +
                         ", timestamp=" + std::to_string(timestamp);
        std::cout << "✓ " << msg << std::endl;
        g_logger.log(g_logger.get_topic_path("remote_control"), msg);
    }
    
    // 5. 发送驾驶状态 (新增)
    long driving_state = (count % 5) + 1;  // 循环1-5的驾驶状态
    if (g_publisher->publishDriveState("/vehicle/drive_state", driving_state)) {
        std::string msg = "DriveState发送成功: driving_state=" + std::to_string(driving_state);
        std::cout << "✓ " << msg << std::endl;
        g_logger.log(g_logger.get_topic_path("drive_state"), msg);
    }
    
    // 6. 发送故障报告 (新增) 
    std::vector<int32_t> fault_types;
    if (count % 3 == 0) {
        // 每3轮发送一个故障
        fault_types = {100, 200};  // 模拟故障类型
    } else {
        fault_types = {0};  // 无故障
    }
    if (g_publisher->publishFaultReport("/vehicle/fault_report", fault_types)) {
        std::string msg = "FaultReport发送成功: fault_count=" + std::to_string(fault_types.size());
        if (fault_types.size() > 1 || fault_types[0] != 0) {
            msg += ", fault_types=[";
            for (size_t i = 0; i < fault_types.size(); ++i) {
                if (i > 0) msg += ",";
                msg += std::to_string(fault_types[i]);
            }
            msg += "]";
        }
        std::cout << "✓ " << msg << std::endl;
        g_logger.log(g_logger.get_topic_path("fault_report"), msg);
    }
}

int main(int argc, char* argv[])
{
    std::cout << "=== 简化版FastDDS发布者 - 车端消息发送测试 ===" << std::endl;
    
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);
    
    // 初始化发布者
    std::cout << "初始化FastDDS发布者..." << std::endl;
    g_publisher = std::make_unique<FastDDSPublisher>();
    if (!g_publisher->init()) {
        std::cerr << "发布者初始化失败" << std::endl;
        return 1;
    }
    std::cout << "✓ 发布者初始化成功\n" << std::endl;
    
    if (argc > 1 && std::string(argv[1]) == "once") {
        // 单次发送模式
        std::cout << "=== 单次发送模式 ===" << std::endl;
        send_test_messages();
        std::cout << "\n单次发送完成" << std::endl;
    } else {
        // 循环发送模式  
        std::cout << "=== 循环发送模式 (每2秒发送一轮) ===" << std::endl;
        std::cout << "按 Ctrl+C 停止\n" << std::endl;
        
        while (g_running) {
            send_test_messages();
            
            // 等待2秒
            for (int i = 0; i < 20 && g_running; ++i) {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
        }
    }
    
    std::cout << "\n清理资源..." << std::endl;
    g_publisher.reset();
    std::cout << "程序退出" << std::endl;
    
    return 0;
}
