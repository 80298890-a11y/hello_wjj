#!/bin/bash

echo "=== 90机器抓取102机器TCP数据 ==="

# 创建日志目录
mkdir -p /home/hello/work/project_root/test/captures

# 获取时间戳
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

echo "1. 启动tcpdump抓包..."
echo "2. 启动subscriber接收数据..."
echo "3. 按Ctrl+C停止"
echo ""

# 在后台启动tcpdump
sudo tcpdump -i enp1s0 -w /home/hello/work/project_root/test/captures/fastdds_tcp_${TIMESTAMP}.pcap host 192.168.2.102 and tcp &
TCPDUMP_PID=$!

echo "✅ tcpdump已启动 (PID: $TCPDUMP_PID)"
echo "📁 抓包文件: /home/hello/work/project_root/test/captures/fastdds_tcp_${TIMESTAMP}.pcap"
echo ""

# 启动subscriber  
cd /home/hello/work/project_root/test/build
echo "🚀 启动subscriber..."
./subscriber

# 清理
echo ""
echo "🛑 停止tcpdump..."
sudo kill $TCPDUMP_PID 2>/dev/null
echo "✅ 完成"
